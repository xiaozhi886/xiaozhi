# 烟花模拟器

注意：此源码是[NianBroken](https://github.com/NianBroken)基于 [XgpNwb](https://codepen.io/MillerTime/pen/XgpNwb) 的二次修改，作翻译处理以及其他优化。

这里我把缩放效果修改了，电脑和手机默认缩放均修改为50%，感觉这样烟花看起来更加真实，观赏效果更佳！

Demo：https://fireworks.yangzhiblog.com

------

展示图

![静态图](https://cdn.jsdelivr.net/gh/NianBroken/Firework_Simulator/Image_Preview.png)

------
